<?php

$regex = '~(\d\d)(\w)~';
$alvo = '11a22b33c';
$resultado = preg_match($regex, $alvo, $match);

$string = 'Setembro 21';
$regex = '~(\w+)\s(\d+)~';
$novoTexto = '$2 de $1';

$resultado = preg_replace($regex, $novoTexto, $string);
echo $resultado; // 21 de Setembro
?>